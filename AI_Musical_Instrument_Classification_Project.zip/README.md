# AI-Based Musical Instrument Classification Using Audio Signals

A reproducible Python capstone that extracts MFCC and spectral features from labeled audio clips, trains an SVM or Random Forest classifier, evaluates unseen test clips, and offers a simple demo.

## What is included
- `src/audio_features.py`: audio loading and feature extraction (MFCC, spectral centroid, zero-crossing rate, chroma, rolloff, RMS).
- `src/prepare_dataset.py`: builds a feature table from class-folder audio data.
- `src/train.py`: trains SVM and Random Forest, selects the better validation macro-F1 model, evaluates on held-out test data, saves the pipeline and reports.
- `src/predict.py`: classify one audio file using the saved model.
- `src/app.py`: optional Streamlit upload demo.
- `notebooks/feature_analysis.py`: notebook-friendly analysis script; run it as a Python script or paste cells into Jupyter.
- `tests/test_features.py`: small feature extraction smoke test.
- `report/PROJECT_REPORT.md`: report template with honest placeholders for your measured results.
- `presentation/PPT_OUTLINE.md`: slide-by-slide presentation outline.
- `data/README.md`: dataset layout and licensing guidance.
- `requirements.txt`, `.gitignore`.

## Quick start
Requires Python 3.10–3.12 recommended.

### 1. Create environment
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 2. Add labeled audio
Arrange your own licensed dataset as:
```text
data/raw/
  guitar/
    guitar_001.wav
    guitar_002.wav
  piano/
    piano_001.wav
    piano_002.wav
  violin/
    violin_001.wav
```
Use at least 3 instrument classes and aim for 50–100+ clips per class if possible. WAV/FLAC/OGG/MP3 are supported by Librosa when its audio backend dependencies are available. Keep the source dataset license and attribution in `data/README.md`.

**Important:** This repository intentionally does not contain copyrighted audio samples or fabricated performance results. The model is trained on the dataset you place in `data/raw`.

### 3. Build feature table and split by audio file
```bash
python -m src.prepare_dataset --data-dir data/raw --output data/processed/features.csv
```
The script extracts one fixed-length feature vector per clip. Train/validation/test splits are performed by file, stratified by class, to keep test clips unseen.

### 4. Train and evaluate
```bash
python -m src.train --features data/processed/features.csv --model-dir models --reports-dir reports
```
The script saves the chosen fitted pipeline to `models/instrument_classifier.joblib`, plus metrics, confusion matrix, and classification report under `reports/`. Compare `validation_results.csv` to see SVM vs Random Forest results. The final held-out test score is reported only after model selection.

### 5. Predict a new clip
```bash
python -m src.predict --model models/instrument_classifier.joblib --audio path/to/new_clip.wav
```

### 6. Optional interactive demo
```bash
streamlit run src/app.py
```
Upload an audio file. The app shows the predicted instrument and class probabilities.

## Dataset notes
- Do not randomly split chunks from the same recording across train and test; this can leak recording-specific information. This project splits clips by file.
- If your dataset has many clips from the same song/session, consider grouping by original recording/performer/session to make evaluation more realistic.
- The test set must not be used to tune features or hyperparameters.
- Accuracy alone can hide class imbalance; use macro precision, macro recall, macro F1 and the confusion matrix too.
- Results depend strongly on dataset size, class balance, recording quality, and whether instruments play solo or together.

## GitHub
1. Do not commit `.venv/`, large raw datasets, personal files, or copyrighted audio without permission.
2. Add dataset source, license, and attribution to `data/README.md`.
3. Commit source, notebooks/scripts, report, PPT outline, and requirements.
4. After running training, include the generated metrics in the report. Do not claim results before running the experiment.

## Troubleshooting
- If Librosa cannot decode MP3, install FFmpeg or use WAV.
- If install fails on a very new Python version, use Python 3.11 or 3.12.
- If you have very few clips per class, stratified splitting may fail; collect more samples or adjust the split ratios in `src/train.py`.
