# Dataset instructions

Place audio files in `data/raw/<instrument_name>/`. Example classes: `guitar`, `piano`, `violin`, `flute`, `trumpet`, `drums`.

## Dataset sources
Choose a labeled dataset whose license allows your intended academic and GitHub use. Possible research datasets to investigate include:
- NSynth (Google Magenta): synthesized individual notes from instruments; check current dataset terms and whether it matches your project.
- IRMAS: music excerpts with instrument labels; check access and license terms.
- Open-source Freesound samples: verify each recording's license and attribution individually.

Do not assume a dataset is public-domain just because it is downloadable. Keep the dataset's original license, citations, and attribution. Do not upload copyrighted recordings or redistribute a dataset unless permitted.

For a first demo, 3–5 instruments with at least 50 clips each is a reasonable goal; more varied recordings improve generalization. Use solo instruments if the objective is to identify the source instrument rather than a mixture.
