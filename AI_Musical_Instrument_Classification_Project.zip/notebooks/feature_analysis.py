"""Notebook-friendly feature analysis. Run after prepare_dataset.py."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

FEATURES = Path("data/processed/features.csv")
df = pd.read_csv(FEATURES)
print("Dataset shape:", df.shape)
print("\nClips per instrument:\n", df["label"].value_counts())
print("\nMissing values:", int(df.isna().sum().sum()))
feature_cols = [c for c in df.columns if c not in ("label", "file_path")]
summary = df.groupby("label")[feature_cols].mean()
print("\nMean features by instrument:\n", summary.iloc[:, :8].round(3))
summary.iloc[:, :12].T.plot(kind="bar", figsize=(13, 5))
plt.title("Mean selected audio features by instrument")
plt.ylabel("Feature value"); plt.tight_layout()
Path("reports").mkdir(exist_ok=True)
plt.savefig("reports/feature_means.png", dpi=160)
plt.show()
