"""Streamlit demo for uploaded audio clips."""
import tempfile
from pathlib import Path
import joblib
import pandas as pd
import streamlit as st
from src.audio_features import extract_features, feature_names

st.set_page_config(page_title="Instrument Classifier", page_icon="🎵", layout="centered")
st.title("🎵 AI-Based Musical Instrument Classification")
st.write("Upload a short audio clip. The model predicts the most likely instrument class.")
model_path = Path("models/instrument_classifier.joblib")
if not model_path.exists():
    st.error("Model not found. Train it first using `python -m src.train`.")
    st.stop()
bundle = joblib.load(model_path)
uploaded = st.file_uploader("Choose an audio file", type=["wav", "flac", "ogg", "mp3", "m4a", "aiff"])
if uploaded:
    st.audio(uploaded)
    suffix = Path(uploaded.name).suffix or ".wav"
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(uploaded.getvalue()); temp_path = tmp.name
        vector = extract_features(temp_path)
        row = pd.DataFrame([dict(zip(feature_names(), vector.tolist()))])[bundle["feature_columns"]]
        model = bundle["model"]
        prediction = model.predict(row)[0]
        st.subheader(f"Predicted instrument: **{prediction}**")
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(row)[0]
            st.bar_chart(pd.DataFrame({"probability": probs}, index=model.classes_))
        Path(temp_path).unlink(missing_ok=True)
    except Exception as exc:
        st.error(f"Could not process this audio: {exc}")
