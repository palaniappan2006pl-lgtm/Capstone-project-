"""Audio loading and fixed-length feature extraction for instrument classification."""
from pathlib import Path
import numpy as np
import librosa

SAMPLE_RATE = 22050
DURATION_SECONDS = 5.0
N_MFCC = 20
N_FFT = 2048
HOP_LENGTH = 512

def extract_features(audio_path, sample_rate=SAMPLE_RATE, duration=DURATION_SECONDS):
    """Return a 1-D numeric feature vector from one audio file.

    Features are time-averaged and time-standard-deviation summaries of MFCCs,
    plus spectral centroid, zero-crossing rate, chroma, rolloff and RMS.
    """
    y, sr = librosa.load(str(audio_path), sr=sample_rate, mono=True, duration=duration)
    if y.size == 0:
        raise ValueError(f"No audio samples decoded from: {audio_path}")
    # Pad short files to ensure stable feature extraction.
    min_len = int(sample_rate * 0.25)
    if len(y) < min_len:
        y = np.pad(y, (0, min_len - len(y)))
    y, _ = librosa.effects.trim(y, top_db=35)
    if y.size == 0:
        raise ValueError(f"Audio is silent or too short after trimming: {audio_path}")
    stft = np.abs(librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LENGTH))
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=N_MFCC, n_fft=N_FFT, hop_length=HOP_LENGTH)
    centroid = librosa.feature.spectral_centroid(S=stft, sr=sr)
    zcr = librosa.feature.zero_crossing_rate(y, frame_length=N_FFT, hop_length=HOP_LENGTH)
    chroma = librosa.feature.chroma_stft(S=stft, sr=sr, hop_length=HOP_LENGTH)
    rolloff = librosa.feature.spectral_rolloff(S=stft, sr=sr)
    rms = librosa.feature.rms(S=stft)
    features = []
    for matrix in (mfcc, centroid, zcr, chroma, rolloff, rms):
        features.extend(np.mean(matrix, axis=1).tolist())
        features.extend(np.std(matrix, axis=1).tolist())
    result = np.asarray(features, dtype=np.float32)
    if not np.all(np.isfinite(result)):
        raise ValueError(f"Non-finite features extracted from: {audio_path}")
    return result

def feature_names():
    names = []
    for prefix, count in (("mfcc", N_MFCC), ("spectral_centroid", 1),
                          ("zero_crossing_rate", 1), ("chroma", 12),
                          ("spectral_rolloff", 1), ("rms", 1)):
        names += [f"{prefix}_{i+1}_mean" for i in range(count)]
        names += [f"{prefix}_{i+1}_std" for i in range(count)]
    return names
