"""Predict the instrument label for one audio clip."""
import argparse
import joblib
import pandas as pd
from src.audio_features import extract_features, feature_names

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="models/instrument_classifier.joblib")
    p.add_argument("--audio", required=True)
    args = p.parse_args()
    bundle = joblib.load(args.model)
    vector = extract_features(args.audio)
    row = pd.DataFrame([dict(zip(feature_names(), vector.tolist()))])
    row = row[bundle["feature_columns"]]
    model = bundle["model"]
    prediction = model.predict(row)[0]
    print(f"Predicted instrument: {prediction}")
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(row)[0]
        classes = model.classes_
        print("Class probabilities:")
        for cls, prob in sorted(zip(classes, probs), key=lambda item: item[1], reverse=True):
            print(f"  {cls}: {prob:.3f}")
if __name__ == "__main__":
    main()
