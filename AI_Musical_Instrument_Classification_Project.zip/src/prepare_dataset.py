"""Extract a labeled feature table from data/raw/<instrument>/* audio files."""
import argparse
from pathlib import Path
import pandas as pd
from src.audio_features import extract_features, feature_names

AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg", ".mp3", ".m4a", ".aiff", ".aif"}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/raw")
    parser.add_argument("--output", default="data/processed/features.csv")
    args = parser.parse_args()
    root = Path(args.data_dir)
    if not root.exists():
        raise SystemExit(f"Dataset directory not found: {root}")
    rows, errors = [], []
    for label_dir in sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith(".")):
        files = sorted(p for p in label_dir.rglob("*") if p.is_file() and p.suffix.lower() in AUDIO_EXTENSIONS)
        for path in files:
            try:
                vector = extract_features(path)
                row = dict(zip(feature_names(), vector.tolist()))
                row.update(label=label_dir.name, file_path=path.as_posix())
                rows.append(row)
            except Exception as exc:
                errors.append((str(path), str(exc)))
                print(f"[WARN] Skipped {path}: {exc}")
    if not rows:
        raise SystemExit("No usable audio found. Add audio files under data/raw/<instrument>/.")
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(output, index=False)
    print(f"Saved {len(df)} clips across {df['label'].nunique()} classes to {output}")
    print(df['label'].value_counts().sort_index().to_string())
    if errors:
        print(f"Skipped {len(errors)} files; see warnings above.")
if __name__ == "__main__":
    main()
