"""Train candidate classifiers, select by validation macro-F1, then evaluate held-out test."""
import argparse, json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             classification_report, confusion_matrix, ConfusionMatrixDisplay)

def metric_row(y_true, y_pred, model_name):
    return {"model": model_name, "accuracy": accuracy_score(y_true, y_pred),
            "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
            "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
            "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", default="data/processed/features.csv")
    parser.add_argument("--model-dir", default="models")
    parser.add_argument("--reports-dir", default="reports")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    df = pd.read_csv(args.features)
    if "label" not in df or "file_path" not in df:
        raise SystemExit("Feature CSV must contain label and file_path columns.")
    counts = df.label.value_counts()
    if len(counts) < 2:
        raise SystemExit("Need at least two instrument classes.")
    if counts.min() < 5:
        raise SystemExit("Need at least 5 usable clips in every class for train/validation/test split.")
    X = df.drop(columns=["label", "file_path"])
    y = df["label"].astype(str)
    # 70/15/15 split, stratified by class and performed at clip/file level.
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, random_state=args.seed, stratify=y)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=args.seed, stratify=y_temp)
    candidates = {
        "SVM_RBF": Pipeline([("scale", StandardScaler()), ("classifier", SVC(
            kernel="rbf", C=10, gamma="scale", probability=True, class_weight="balanced",
            random_state=args.seed))]),
        "Random_Forest": RandomForestClassifier(n_estimators=400, class_weight="balanced",
            random_state=args.seed, n_jobs=-1, min_samples_leaf=1)
    }
    out_model, out_reports = Path(args.model_dir), Path(args.reports_dir)
    out_model.mkdir(parents=True, exist_ok=True); out_reports.mkdir(parents=True, exist_ok=True)
    val_rows = []
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        val_rows.append(metric_row(y_val, model.predict(X_val), name))
    val_df = pd.DataFrame(val_rows).sort_values("f1_macro", ascending=False)
    val_df.to_csv(out_reports / "validation_results.csv", index=False)
    best_name = val_df.iloc[0]["model"]
    best = candidates[best_name]
    # Refit chosen model on train + validation; test remains untouched until this point.
    X_trainval = pd.concat([X_train, X_val], axis=0)
    y_trainval = pd.concat([y_train, y_val], axis=0)
    best.fit(X_trainval, y_trainval)
    pred = best.predict(X_test)
    metrics = metric_row(y_test, pred, best_name)
    metrics.update({"selected_by": "validation macro-F1", "random_seed": args.seed,
                    "n_total": int(len(df)), "n_train": int(len(X_train)),
                    "n_validation": int(len(X_val)), "n_test": int(len(X_test)),
                    "class_counts": {str(k): int(v) for k,v in counts.items()}})
    (out_reports / "test_metrics.json").write_text(json.dumps(metrics, indent=2))
    report = classification_report(y_test, pred, output_dict=True, zero_division=0)
    pd.DataFrame(report).transpose().to_csv(out_reports / "classification_report.csv")
    labels = sorted(y.unique())
    cm = confusion_matrix(y_test, pred, labels=labels)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    fig, ax = plt.subplots(figsize=(max(7, len(labels)*1.1), max(6, len(labels)*0.9)))
    disp.plot(ax=ax, xticks_rotation=45, colorbar=False)
    ax.set_title(f"Test confusion matrix — {best_name}")
    fig.tight_layout(); fig.savefig(out_reports / "confusion_matrix.png", dpi=160); plt.close(fig)
    joblib.dump({"model": best, "feature_columns": list(X.columns), "classes": labels,
                 "selected_model": best_name}, out_model / "instrument_classifier.joblib")
    print("Validation comparison:\n", val_df.to_string(index=False))
    print("\nHeld-out test metrics:\n", json.dumps(metrics, indent=2))
    print(f"\nSaved model: {out_model / 'instrument_classifier.joblib'}")
    print(f"Saved reports: {out_reports.resolve()}")
if __name__ == "__main__":
    main()
