import numpy as np
import soundfile as sf
from src.audio_features import extract_features, feature_names

def test_feature_vector_on_synthetic_tone(tmp_path):
    sr = 22050
    t = np.arange(sr) / sr
    y = 0.2 * np.sin(2 * np.pi * 440 * t)
    path = tmp_path / "tone.wav"
    sf.write(path, y, sr)
    features = extract_features(path)
    assert features.ndim == 1
    assert len(features) == len(feature_names())
    assert np.isfinite(features).all()
